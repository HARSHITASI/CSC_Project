module.exports = {
  extends: "google"
};
